//export const 
function timeFormat(nS) {
    // /Date(1555554794000)/ 转换为 2019/4/18
    // return new Date(parseInt(("/Date("+nS+")/").substr(6,
    // 13))).toLocaleDateString();
    // /Date(1555554794000)/ 转换为 2019/4/18 上午10:33:14
    // return new Date(parseInt(("/Date("+nS+")/").substr(6,
    // 13))).toLocaleString()
    // js转换时间戳-转换成 yyyy-MM-dd HH:mm:ss
    var date = new Date(nS);
      var YY = date.getFullYear() + '-';
      var MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
      var DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
      var hh = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
      var mm = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
      var ss = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
      return YY + MM + DD +" "+hh + mm + ss;
};
module.exports = {
    timeFormat: timeFormat
}