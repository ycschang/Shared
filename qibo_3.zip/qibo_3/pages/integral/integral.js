//0 引入用来发送请求的方法
import { request } from "../../request/request.js";
var util = require('../../utils/utils.js');
//引入组件中的js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    result:[],
    nickName:""

  },
  onLoad: function (options) {
    //向后台发送请求拿到全部积分 剩余积分 积分流水
    const userInfo = wx.getStorageSync("userInfo");
    //console.log(userInfo);
    
    let openId =  userInfo.openid;
    //console.log(openId);
    request({url:"customer/getCustomerIntegralList.action",data:{'openId':openId}})
    .then(result =>{
      //拿到后台返回的积分数组
      let integralMsg = result.data;
      //对后台传回的对象中的日期属性进行转换
      for(var i=0;i<integralMsg.length;i++){
        //获取后台传回数据类型（主要是十三位number日期的转换）
        let dataType = Object.prototype.toString.call(integralMsg[i].create_date);
        //判断日期类型是否是num类型，是的话转换成date类型
        dataType === '[object Number]'?integralMsg[i].create_date =util.timeFormat(integralMsg[i].create_date): integralMsg[i].create_date =''
      }
      //获取客户nickName
      const userInfo = wx.getStorageSync("userInfo");
      console.log(integralMsg);
      //把数据放入data中
      this.setData({
          nickName: userInfo.nickName,
          result:integralMsg
      });
    })
  }
})