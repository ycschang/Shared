// pages/JJJF/JJJF.js
import { request } from "../../request/request.js";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nickName:"",
    openid:"",
    result:{},
    integral:0,
    point:0
  },
  //获取二维码中的用户名 openId
  getScancode: function () {
    var _this = this;
    wx.scanCode({
      success: (res) => {
        var result = res.result.split(',');
        //var res = result.split(',');
        _this.setData({
          nickName: result[0],
          openid:result[1],
          point:result[2]
        })
      }
    })
  },
  //获取输入框的积分
  handleIntegral:function(e){
    this.setData({
      integral: e.detail.value
    })
  },
  addIntegral:function() {
    var that = this;
    
    const userInfo = wx.getStorageSync("userInfo");
    //console.log();
    var pOpenId = userInfo.openid;
    //console.log(that.data);
    request({url:"customer/addOrCutIntegral.action"
    ,method:'post'
    // ,data:{
    //   nickName:'nickName',addIntegral:10
    // }
    ,data: JSON.stringify({
      add_points:that.data.integral,openid:that.data.openid,point:that.data.point,pOpenId:pOpenId
    }),
    })
    .then(result => {
      if(result.data.code == 200) {
        wx.showToast({
          title: '操作成功！', // 标题
          icon: 'success',  // 图标类型，默认success
          duration: 1500  // 提示窗停留时间，默认1500ms
        })
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateBack({
            delta: 1
          });
         }, 3000) //延迟时间 这里是1秒
        
      } else {
        wx.showToast({
          title: '失败', // 标题
          icon: 'none',  // 图标类型，默认success
          duration: 1500  // 提示窗停留时间，默认1500ms
        })
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateBack({
            delta: 1
          });
         }, 3000) //延迟时间 这里是1秒
      }
      // console.log(result);
      // this.setData({
      //   result:result
      // })
    })
  },
  cutIntegral:function() {
    var that = this;
    const userInfo = wx.getStorageSync("userInfo");
    //console.log();
    var pOpenId = userInfo.openid;
    //console.log(that.data);
    request({url:"customer/addOrCutIntegral.action"
    ,method:'post'
    // ,data:{
    //   nickName:'nickName',addIntegral:10
    // }
    ,data: JSON.stringify({
      reduce_points:that.data.integral*-1,openid:that.data.openid,point:that.data.point,pOpenId:pOpenId
    }),
    })
    .then(result => {
      // console.log(result);
      // this.setData({
      //   result:result
      // })
      if(result.data.code == 200) {
        wx.showToast({
          title: '操作成功！', // 标题
          icon: 'success',  // 图标类型，默认success
          duration: 1500  // 提示窗停留时间，默认1500ms
        })
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateBack({
            delta: 1
          });
         }, 3000) //延迟时间 这里是1秒
        
      } else {
        wx.showToast({
          title: '失败', // 标题
          icon: 'none',  // 图标类型，默认success
          duration: 1500  // 提示窗停留时间，默认1500ms
        })
        setTimeout(function () {
          //要延时执行的代码
          wx.navigateBack({
            delta: 1
          });
         }, 3000) //延迟时间 这里是1秒
      }
    })
  }
})