// pages/user/user.js
import regeneratorRuntime from "../../lib/runtime/runtime";
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userInfo:{},
    result: ""
  },
  onShow(){
    const userInfo = wx.getStorageSync("userInfo");
    //console.log(JSON.stringify(userInfo));
    this.setData({userInfo});
  },
  handleSecede(){
    wx.removeStorage({key: 'userInfo'});
    const userInfo = wx.getStorageSync("userInfo");
    if(userInfo != null){
      wx.navigateTo({url:"/pages/login/login"});
    } else {
      alert(66666);
    }
  }
})