// pages/login/login.js
//0 引入用来发送请求的方法
import { request } from "../../request/request.js";
Page({

  data: {
    userInfo:{}
  },
  handleGetUserInfo(e){
    //console.log(e);
    // const {userInfo} = e.detail;
    // wx.setStorageSync("userInfo", userInfo);
    // wx.navigateBack({
    //   delta: 1
    // });
    var that = this;
    wx.login({
      success (res) {
        if (res.code) {
          console.log(res.code);
          var appid = 'wx8868b07326084842';//
          var secret = '7243881b0960ac277f78957f2ea13062';
          request({url:"customer/getOpenId.action",data:{url:'https://api.weixin.qq.com/sns/jscode2session?appid='+appid+'&secret='+secret+'&js_code=' + res.code + '&grant_type=authorization_code'},method:'post'})
          .then(res =>{
            //console.log(JSON.stringify(res.data.openid)+6666667);
            const {userInfo} = e.detail;
            let openid=res.data.openid;
            userInfo['openid'] = openid;
            that.setData({
              userInfo:userInfo
            });
            //console.log(userInfo);
            request({url:"customer/addCustomer.action",data:{'userInfo':userInfo}}).then(result =>{
              if(result.data.code == 200) {
                  wx.setStorageSync("userInfo", userInfo);
                  wx.navigateBack({
                    delta: 1
                  });
              } else if(result.data.code == 0){
                console.log("添加失败")
              } else {
                console.log("未知错误");
              }
            })
          })
          // wx.request({
          //     // 自行补上自己的 APPID 和 SECRET
          //     url: 'https://api.weixin.qq.com/sns/jscode2session?appid='+appid+'&secret='+secret+'&js_code=' + res.code + '&grant_type=authorization_code',
          //     success: res => {
          //         // 获取到用户的 openid
          //         //console.log("用户的openid:" + res.data.openid);
          //         const {userInfo} = e.detail;
          //         let openid=res.data.openid;
          //         userInfo['openid'] = openid;
          //         that.setData({
          //           userInfo:userInfo
          //         });
          //         console.log(userInfo);
          //         request({url:"customer/addCustomer.action",data:{'userInfo':userInfo}}).then(result =>{
          //           if(result.data.code == 200) {
          //              wx.setStorageSync("userInfo", userInfo);
          //              wx.navigateBack({
          //                delta: 1
          //              });
          //           } else if(result.data.code == 0){
          //             console.log("添加失败")
          //           } else {
          //             console.log("未知错误");
          //           }
          //         })
          //     }
          // });
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
    
  }
})