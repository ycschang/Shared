export const request=(params)=>{
    //定义公共的url
    //const baseUrl = "http://localhost:8080/qibo_3/"
    const baseUrl = "https://www.wldyxy.top/qibo_3/" 
    return new Promise((resolve,reject)=>{
        wx.request({
            ...params,
            url:baseUrl+params.url,
            method:"post",
            success:(result) => {
                resolve(result);
            },
            fail:(err) =>{
                reject(err);
            }
        })
    })
}